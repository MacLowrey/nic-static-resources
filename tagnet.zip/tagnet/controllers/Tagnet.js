'use strict';

/**
 * Tagnet.js controller
 *
 * @description: A set of functions called "actions" for managing `Tagnet`.
 */

module.exports = {

  /**
   * Retrieve tagnet records.
   *
   * @return {Object|Array}
   */

  find: async (ctx) => {
    if (ctx.query._q) {
      return strapi.services.tagnet.search(ctx.query);
    } else {
      return strapi.services.tagnet.fetchAll(ctx.query);
    }
  },

 /**
   * Retrieve single object written by Jon 
   *
   * @return {Object}
   */

  findObj: async (ctx) => {
    if (ctx.query._q) {
      return strapi.services.tagnet.search(ctx.query);
    } else {
      return strapi.services.tagnet.fetchObj(ctx.query);
    }
  },

  /**
   * Retrieve a tagnet record.
   *
   * @return {Object}
   */

  findOne: async (ctx) => {
    if (!ctx.params.AgentNumber.match(/^[0-9a-fA-F]*$/)) {
     	 return ctx.notFound();
    }

    return strapi.services.tagnet.fetch(ctx.params);
  },

  /**
   * Count tagnet records.
   *
   * @return {Number}
   */

  count: async (ctx) => {
    return strapi.services.tagnet.count(ctx.query);
  },

  /**
   * Create a/an tagnet record.
   *
   * @return {Object}
   */

  create: async (ctx) => {
    return strapi.services.tagnet.add(ctx.request.body);
  },

  /**
   * Update a/an tagnet record.
   *
   * @return {Object}
   */

  update: async (ctx, next) => {
  console.log("CTX",ctx);
  console.log("NEXT", next);
  console.log("CTX params",ctx.params);
  console.log("CTX Request Body", ctx.request.body);
	  
	return strapi.services.tagnet.edit(ctx.params, ctx.request.body) ;
  },

  /**
   * Destroy a/an tagnet record.
   *
   * @return {Object}
   */

  destroy: async (ctx, next) => {
    return strapi.services.tagnet.remove(ctx.params);
  }
};
